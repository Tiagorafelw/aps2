const secret = "7D0BE37A47D355368D62DAC466CCA661"

export default {secret}