
import app from "./src/app.js";

const PORT = 3005;

app.listen(PORT, () => {
    console.log("Servidor na escuta!");
});
 