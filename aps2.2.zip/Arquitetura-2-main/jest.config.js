export default{
    testEnviroment: "node",
    transform: {},
}